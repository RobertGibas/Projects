﻿namespace StarWarsCharacters.Response;

public class BaseCharacterInfo
{
    public string Name { get; set; }
    public string BirthYear { get; set; }
    public string Gender { get; set; }
}